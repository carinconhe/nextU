import React from 'react';

class Error extends React.Component{
  render(){
    return(
      <div >
        Hola React Error
      </div>
    );
  }
}
export default Error;
