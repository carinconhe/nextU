import { AppRegistry } from 'react-native';
import App from './src/App';

AppRegistry.registerComponent('laDeportiva', () => App);