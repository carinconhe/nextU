import React, { Component } from 'react';
import {View} from 'react-native';
import Formulario  from './Formulario';

class Login extends Component {
    
    render() {
        return (
            <View>
                <Formulario/>
            </View>
        );
    }
}

export default Login;
