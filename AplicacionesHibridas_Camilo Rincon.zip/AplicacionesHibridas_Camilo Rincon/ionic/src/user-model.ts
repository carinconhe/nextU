export interface User{
    username: string;
    password: string;
    name?: string;  //El caracter ? quiere indicar que es opcional.
    email?: string; //El caracter ? quiere indicar que es opcional.   
}